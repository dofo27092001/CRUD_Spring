function eliminar(id){
swal({
  title: "¿Estas seguro de Eliminar?",
  text: "Esta accion no se podra deshacer!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((OK) => {
  if (OK) {
  		$.ajax({
  		url:"/eliminar/"+id,
  		success: function(res){
  			console.log(res);
  		}
  		});
    swal("Perfecto! Se ha Eliminado Correctamente!", {
      icon: "success",
    }).then((ok)=>{
    if(ok){
    location.href="/listar";
    }
    });
  } else {
    swal("Your imaginary file is safe!");
  }
});
}